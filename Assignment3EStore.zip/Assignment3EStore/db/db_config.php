<?php
/* Feenix-MariaDB credentials – DO NOT commit to Git! */
return [
    'host'   => 'feenix-mariadb.swin.edu.au',
    'user'   => 's104548601',
    'pass'   => '12345',          // change later if you’ve reset the DB password - NEEDS TO BE BETTER
    'dbname' => 's104548601_db',
];
