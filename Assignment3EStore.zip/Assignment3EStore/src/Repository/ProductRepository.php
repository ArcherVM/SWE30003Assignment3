<?php
// File: src/Repository/ProductRepository.php

/**
 * Simple mysqli-based repository for the `product` table.
 * All public methods throw mysqli_sql_exception on DB errors.
 */
class ProductRepository
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    /** Return all products as an array of associative arrays. */
    public function all()
    {
        $sql = 'SELECT product_id, sku, name, description, price_cents, stock_qty
                  FROM product
              ORDER BY name';

        $result = $this->db->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    /** Find one product by its ID. Returns an associative array or null. */
    public function find($id)
    {
        $stmt = $this->db->prepare(
            'SELECT product_id, sku, name, description, price_cents, stock_qty
               FROM product
              WHERE product_id = ?'
        );
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ? $row : null;
    }

    /** Insert a new product. Returns true on success. */
    public function create($sku, $name, $desc, $priceCents, $stockQty)
    {
        $stmt = $this->db->prepare(
            'INSERT INTO product (sku, name, description, price_cents, stock_qty)
                       VALUES (?,?,?,?,?)'
        );
        $stmt->bind_param('sssii', $sku, $name, $desc, $priceCents, $stockQty);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    /** Update an existing product. Returns true if at least one row changed. */
    public function update($id, $sku, $name, $desc, $priceCents, $stockQty)
    {
        $stmt = $this->db->prepare(
            'UPDATE product
                SET sku=?, name=?, description=?, price_cents=?, stock_qty=?
              WHERE product_id=?'
        );
        $stmt->bind_param('sssiii', $sku, $name, $desc, $priceCents, $stockQty, $id);
        $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();
        return ($affected > 0);
    }

    /** Hard-delete by ID. Returns true on success. */
    public function delete($id)
    {
        return $this->db->query(
            'DELETE FROM product WHERE product_id = ' . (int) $id
        );
    }

    /** Check for unique SKU (optionally excluding a given product ID). */
    public function skuExists($sku, $excludeId = null)
    {
        $sql = 'SELECT 1 FROM product WHERE sku = ?';
        if ($excludeId !== null) {
            $sql .= ' AND product_id <> ' . (int) $excludeId;
        }

        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('s', $sku);
        $stmt->execute();
        $stmt->store_result();
        $found = ($stmt->num_rows === 1);
        $stmt->close();
        return $found;
    }

    /** Check ID existence without fetching the row. */
    public function exists($id)
    {
        $stmt = $this->db->prepare(
            'SELECT 1 FROM product WHERE product_id = ? LIMIT 1'
        );
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->store_result();
        $found = ($stmt->num_rows === 1);
        $stmt->close();
        return $found;
    }

    /** Optional helper to close the underlying mysqli link if desired. */
    public function close()
    {
        $this->db->close();
    }
}
