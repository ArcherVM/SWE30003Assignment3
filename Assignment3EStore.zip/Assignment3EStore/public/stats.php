<?php
session_start();
require_once __DIR__ . '/../db/setup_db.php';  // sets $link

// ─── Access control: only admin ─────────────────────────────────────────
if (empty($_SESSION['is_admin'])) {
    header('Location: /admin.php');
    exit;
}

// ─── Aggregate sales stats ──────────────────────────────────────────────
$sql = <<<SQL
SELECT
  p.product_id,
  p.sku,
  p.name,
  SUM(oi.qty) AS units_sold,
  SUM(oi.qty * oi.unit_price_cents) AS revenue_cents
FROM order_item AS oi
JOIN product    AS p ON p.product_id = oi.product_id
GROUP BY p.product_id, p.sku, p.name
ORDER BY units_sold DESC
LIMIT 10
SQL;

$result = mysqli_query($link, $sql);
if (!$result) {
    die('Error retrieving statistics: ' . mysqli_error($link));
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Sales Statistics</title>
  <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/milligram/1.4.1/milligram.min.css">
  <style>
    html { font-size: 18px; }
    body {
      background: #f4f4f4;
      font-family: 'Helvetica Neue', Arial, sans-serif;
      color: #333;
      line-height: 1.6;
    }
    .container {
      max-width: 1000px;
      margin: 3rem auto;
      background: #fff;
      padding: 2.5rem;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    nav {
      display: flex;
      gap: 1.5rem;
      margin-bottom: 2rem;
      font-size: 1.1rem;
    }
    nav a {
      color: #555;
      text-decoration: none;
      padding: 0.25rem 0.5rem;
    }
    nav a:hover { color: #5a2d82; }
    h2 {
      font-size: 2rem;
      color: #5a2d82;
      margin-bottom: 1.5rem;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 1rem;
    }
    thead {
      background: #fafafa;
      border-bottom: 2px solid #ddd;
    }
    th, td {
      padding: 0.75rem 1rem;
      text-align: left;
    }
    thead th {
      font-size: 1.1rem;
      color: #444;
    }
    tbody tr:nth-child(even) {
      background: #f9f9f9;
    }
    td {
      font-size: 1rem;
      color: #333;
    }
    .no-data {
      font-size: 1.1rem;
      font-style: italic;
      color: #777;
    }
    .invoice-list {
      margin-top: 2.5rem;
    }
    .invoice-list h3 {
      font-size: 1.5rem;
      color: #5a2d82;
      margin-bottom: 1rem;
    }
    .invoice-list ul {
      list-style: none;
      padding-left: 0;
    }
    .invoice-list li {
      margin-bottom: 0.5rem;
    }
    .invoice-list a {
      color: #5a2d82;
      text-decoration: none;
    }
    .invoice-list a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- Navigation Bar -->
    <nav>
      <a href="./index.php">Shop</a>
      <a href="./cart.php">Cart (<?php echo array_sum(isset($_SESSION['cart']) ? $_SESSION['cart'] : []); ?>)</a>
      <a href="./admin.php">Admin</a>
      <a href="./stats.php">Stats</a>
      <a href="./admin.php?logout=1">Logout</a>
    </nav>

    <h2>Top-10 Best-Selling Products</h2>

    <?php if (mysqli_num_rows($result) === 0): ?>
      <p class="no-data">No sales yet.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>SKU</th>
            <th>Name</th>
            <th>Units Sold</th>
            <th>Revenue</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
              <td><?php echo htmlspecialchars($row['sku']); ?></td>
              <td><?php echo htmlspecialchars($row['name']); ?></td>
              <td><?php echo (int)$row['units_sold']; ?></td>
              <td>$<?php echo number_format($row['revenue_cents'] / 100, 2); ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    <?php endif; ?>

    <!-- ─────── 10️⃣ List all invoices from the invoices folder ─────── -->
    <div class="invoice-list">
      <h3>All Invoices</h3>
      <?php
        // Path to the invoices directory on the filesystem:
        $invoiceDirPath = __DIR__ . '/invoices';

        // URL prefix for linking to each invoice:
        $baseUrl = '/cos30043/s103322558/Assignment3EStore/public/invoices/';

        if (is_dir($invoiceDirPath)) {
            $files = scandir($invoiceDirPath);
            // Filter for PDF files only:
            $pdfFiles = array_filter($files, function($f) use ($invoiceDirPath) {
                return is_file($invoiceDirPath . '/' . $f) && preg_match('/\.pdf$/i', $f);
            });

            if (empty($pdfFiles)) {
                echo '<p class="no-data">(No invoices found.)</p>';
            } else {
                echo '<ul>';
                // Sort files by name (or modify to sort by date if desired):
                sort($pdfFiles, SORT_NATURAL | SORT_FLAG_CASE);
                foreach ($pdfFiles as $file) {
                    $url = $baseUrl . rawurlencode($file);
                    echo '<li><a href="' . htmlspecialchars($url) . '" target="_blank">'
                         . htmlspecialchars($file) . '</a></li>';
                }
                echo '</ul>';
            }
        } else {
            echo '<p class="no-data">(Invoices directory not found.)</p>';
        }
      ?>
    </div>
  </div>
</body>
</html>
