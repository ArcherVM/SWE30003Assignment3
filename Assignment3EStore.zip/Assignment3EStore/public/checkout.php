<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// ─────────── 1️⃣ Include PHPMailer & FPDF at the very top ───────────
require_once __DIR__ . '/lib/PHPMailer/Exception.php';
require_once __DIR__ . '/lib/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/lib/PHPMailer/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// ─────────── 2️⃣ Include FPDF for PDF generation ───────────
require_once __DIR__ . '/lib/fpdf/fpdf.php';

// ─────────── 3️⃣ Include your existing setup files ───────────
require_once __DIR__ . '/../db/setup_db.php';
require_once __DIR__ . '/../src/Repository/ProductRepository.php';
require_once __DIR__ . '/../src/Repository/OrderRepository.php';

$repo = new ProductRepository($link);  // No namespaces on Mercury
// Replace null-coalescing with isset
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];

$msg         = '';
$invoiceHTML = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay'])) {
    // 1️⃣ Gather & validate inputs
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $ok =
        filter_var($email, FILTER_VALIDATE_EMAIL) &&
        !empty($_POST['cc'])  && preg_match('/^\d{16}$/',   $_POST['cc']) &&
        !empty($_POST['exp']) && preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $_POST['exp']) &&
        !empty($_POST['cvv']) && preg_match('/^\d{3}$/',    $_POST['cvv']) &&
        !empty($_POST['name']);

    if ($ok) {
        // 2️⃣ Persist order + items
        $orderRepo = new OrderRepository($link);
        $orderId   = $orderRepo->createOrder($cart, /* customer_id */ null);

        // 3️⃣ Deduct stock
        $stmt = $link->prepare("
            UPDATE product
               SET stock_qty = GREATEST(stock_qty - ?, 0)
             WHERE product_id = ?
        ");
        foreach ($cart as $pid => $qty) {
            $stmt->bind_param('ii', $qty, $pid);
            $stmt->execute();
        }
        $stmt->close();

        // 4️⃣ Build invoice content (plain‐text for email + HTML for page)
        $stmt = $link->prepare("
            SELECT p.name, oi.qty, oi.unit_price_cents
              FROM order_item oi
              JOIN product p ON oi.product_id = p.product_id
             WHERE oi.order_id = ?
        ");
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $stmt->bind_result($prodName, $qty, $unitPriceCents);

        $lines      = [];
        $totalCents = 0;
        $htmlLines  = '';
        while ($stmt->fetch()) {
            $lineTotalCents = $unitPriceCents * $qty;
            $totalCents    += $lineTotalCents;
            $plainLine = sprintf(
                "%s – Qty: %d @ \$%.2f = \$%.2f",
                $prodName,
                $qty,
                $unitPriceCents / 100,
                $lineTotalCents / 100
            );
            $lines[]    = $plainLine;
            $htmlLines .= '<li>' . htmlspecialchars($plainLine) . '</li>';
        }
        $stmt->close();

        $subject      = "Invoice #{$orderId} from YourStore";
        $plainMessage = "Thank you for your order #{$orderId}!\n\n"
                      . "Order details:\n"
                      . implode("\n", $lines) . "\n\n"
                      . "Order Total: \$" . number_format($totalCents / 100, 2) . "\n\n"
                      . "We appreciate your business.\n";

        // 5️⃣ Build HTML invoice for display on page
        $invoiceHTML = "
        <section class=\"invoice-section\">
          <h3>Invoice #{$orderId}</h3>
          <ul>
            {$htmlLines}
          </ul>
          <p><strong>Total: \$" . number_format($totalCents / 100, 2) . "</strong></p>
        </section>";

        // ─────────── 6️⃣ Generate PDF via FPDF and save in public/invoices/ ───────────
        $pdf = new FPDF('P', 'mm', 'A4');
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(0, 10, "Invoice #{$orderId}", 0, 1, 'C');
        $pdf->Ln(5);

        // Table header
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(80, 8, 'Product', 1);
        $pdf->Cell(30, 8, 'Qty', 1, 0, 'R');
        $pdf->Cell(40, 8, 'Unit Price', 1, 0, 'R');
        $pdf->Cell(40, 8, 'Line Total', 1, 1, 'R');

        // Table rows
        $pdf->SetFont('Arial','',12);
        foreach ($cart as $pid => $qty) {
            $p = $repo->find($pid);
            if ($p) {
                $unitPrice = $p['price_cents'] / 100;
                $lineTotal = $unitPrice * $qty;
                $pdf->Cell(80, 8, $p['name'], 1);
                $pdf->Cell(30, 8, $qty, 1, 0, 'R');
                $pdf->Cell(40, 8, sprintf('$%.2f', $unitPrice), 1, 0, 'R');
                $pdf->Cell(40, 8, sprintf('$%.2f', $lineTotal), 1, 1, 'R');
            }
        }

        // Total row
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(110, 8, '', 0);
        $pdf->Cell(40, 8, 'Total:', 1);
        $pdf->Cell(40, 8, sprintf('$%.2f', $totalCents / 100), 1, 1, 'R');

        // Ensure public/invoices/ exists
        $invoiceDir = __DIR__ . '/invoices';
        if (!is_dir($invoiceDir)) {
            mkdir($invoiceDir, 0755, true);
        }
        // Save PDF to public/invoices/invoice-{$orderId}.pdf
        $pdfFilename = $invoiceDir . "/invoice-{$orderId}.pdf";
        $pdf->Output('F', $pdfFilename);

        // ─────────── 7️⃣ PHPMailer + Swinburne SMTP Configuration ───────────
        $mail = new PHPMailer(true);
        try {
            // 7.1️⃣ Load credentials from environment (set in .htaccess)
            $smtpUsername = getenv('SMTP_USER');  // 103322558@student.swin.edu.au
            $smtpPassword = getenv('SMTP_PASS');  // your Swin password

            // 7.2️⃣ Tell PHPMailer to use Swinburne’s SMTP on port 587 with TLS
            $mail->isSMTP();
            $mail->Host       = 'smtp.swin.edu.au';
            $mail->SMTPAuth   = true;
            $mail->Username   = $smtpUsername;
            $mail->Password   = $smtpPassword;
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            // 7.3️⃣ Sender & recipient
            $mail->setFrom('103322558@student.swin.edu.au', 'YourStore Sales');
            $mail->addAddress($email);

            // 7.4️⃣ Subject & body
            $mail->Subject = $subject;
            $mail->Body    = $plainMessage;
            // If you want HTML-formatted email, you could do:
            // $mail->isHTML(true);
            // $mail->Body    = $invoiceHTML;
            // $mail->AltBody = $plainMessage;

            // 7.5️⃣ Attach the PDF invoice
            $mail->addAttachment($pdfFilename, "Invoice-{$orderId}.pdf");

            // 7.6️⃣ Send
            $mail->send();
            $msg = "✅ Payment accepted. Your order #{$orderId} has been placed and an invoice was emailed to {$email}.";
        } catch (Exception $e) {
            error_log("PHPMailer Error (Swin SMTP): " . $mail->ErrorInfo);
            $msg = "✅ Payment accepted. Your order #{$orderId} has been placed, but we couldn't send the invoice email.";
        }

        // ─────────── 8️⃣ Append a “Download your PDF Invoice” link ───────────
        $publicInvoiceUrl = '/cos30043/s103322558/Assignment3EStore/public/invoices/invoice-' . $orderId . '.pdf';
        $msg .= "<br>⬇ <a href=\"$publicInvoiceUrl\" target=\"_blank\">Download your PDF Invoice</a>";

        // ─────────── 9️⃣ Clear the cart ───────────
        $_SESSION['cart'] = [];
    } else {
        $msg = '❌ Please correct the highlighted fields (including a valid email).';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Checkout</title>
  <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/milligram/1.4.1/milligram.min.css">
  <style>
    html { font-size: 18px; }
    body {
      background: #f4f4f4;
      font-family: 'Helvetica Neue', Arial, sans-serif;
      color: #333;
      line-height: 1.6;
    }
    .container {
      max-width: 800px;
      margin: 3rem auto;
      background: #fff;
      padding: 2.5rem;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    nav {
      display: flex;
      gap: 1.5rem;
      margin-bottom: 2rem;
      font-size: 1.1rem;
    }
    nav a {
      color: #555;
      text-decoration: none;
      padding: 0.25rem 0.5rem;
    }
    nav a:hover {
      color: #5a2d82;
    }
    h2 {
      font-size: 2rem;
      color: #5a2d82;
      margin-bottom: 1.5rem;
    }
    form label {
      display: block;
      margin-bottom: 1rem;
      font-weight: bold;
    }
    form input[type="email"],
    form input[type="text"] {
      width: 100%;
      padding: 0.75rem;
      font-size: 1rem;
      border: 1px solid #ddd;
      border-radius: 4px;
      margin-top: 0.5rem;
    }
    .row {
      display: flex;
      gap: 1rem;
    }
    .column {
      flex: 1;
    }
    .button-primary {
      background: #5a2d82;
      color: #fff;
      padding: 0.75rem 1.5rem;
      border: none;
      border-radius: 6px;
      font-size: 1rem;
      cursor: pointer;
      margin-top: 1.5rem;
    }
    .button-primary:hover {
      background: #6e3a9e;
    }
    p.message {
      font-size: 1.1rem;
      margin-bottom: 1.5rem;
    }
    .invoice-section {
      margin-top: 2.5rem;
      background: #fafafa;
      padding: 1.5rem;
      border-radius: 6px;
      border: 1px solid #eee;
    }
    .invoice-section h3 {
      margin-top: 0;
      font-size: 1.5rem;
      color: #333;
    }
    .invoice-section ul {
      padding-left: 1.25rem;
      margin: 1rem 0;
    }
    .invoice-section li {
      margin-bottom: 0.5rem;
      font-size: 1rem;
    }
    .invoice-section p strong {
      font-size: 1.2rem;
    }
    .continue-link {
      display: block;
      margin-top: 2rem;
      color: #555;
      text-decoration: none;
    }
    .continue-link:hover {
      color: #5a2d82;
    }
  </style>
</head>
<body>
  <div class="container">

    <!-- Navigation Bar -->
    <nav>
      <a href="./index.php">Shop</a>
      <a href="./cart.php">Cart (<?php echo array_sum(isset($_SESSION['cart']) ? $_SESSION['cart'] : []); ?>)</a>
      <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
        <a href="./admin.php">Admin</a>
        <a href="./stats.php">Stats</a>
      <?php endif; ?>
    </nav>

    <h2>Checkout (Fake Payment)</h2>

    <?php if (!empty($msg)): ?>
      <p class="message"><?php echo $msg; ?></p>
    <?php endif; ?>

    <form method="post">
      <label>Email Address
        <input type="email" name="email" required
               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
      </label>

      <label>Cardholder Name
        <input type="text" name="name" required
               value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
      </label>

      <label>Card Number (16 digits)
        <input type="text" name="cc" pattern="\d{16}" required
               value="<?php echo isset($_POST['cc']) ? htmlspecialchars($_POST['cc']) : ''; ?>">
      </label>

      <div class="row">
        <div class="column">
          <label>Expiry MM/YY
            <input type="text" name="exp"
                   pattern="(0[1-9]|1[0-2])/\d{2}" required placeholder="07/27"
                   value="<?php echo isset($_POST['exp']) ? htmlspecialchars($_POST['exp']) : ''; ?>">
          </label>
        </div>
        <div class="column">
          <label>CVV
            <input type="text" name="cvv" pattern="\d{3}" required
                   value="<?php echo isset($_POST['cvv']) ? htmlspecialchars($_POST['cvv']) : ''; ?>">
          </label>
        </div>
      </div>

      <button class="button-primary" type="submit" name="pay">Pay Now</button>
    </form>

    <?php
    // 8️⃣ Display the invoice below the form if generated
    if (!empty($invoiceHTML)) {
        echo $invoiceHTML;
    }
    ?>

    <a href="/cart.php" class="continue-link">← Back to Cart</a>
  </div>
</body>
</html>
